"use strict";
exports.id = 789;
exports.ids = [789];
exports.modules = {

/***/ 2789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_NavBarSectores)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/logo-HPampa.png
/* harmony default export */ const logo_HPampa = ({"src":"/_next/static/media/logo-HPampa.2f92e593.png","height":633,"width":1510,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAHlBMVEUAAAAAAAAAAAAer9QAAAAAAAAaiqoXfJUAFRUivuUSP6vSAAAACnRSTlMHjplMFzM5hQxuGL/1fQAAAAlwSFlzAAAuIwAALiMBeKU/dgAAAB9JREFUeJxjYGZjZQADTnZGJiZGJkYGZmYGFhZWVhYAA18ARDOGLc0AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":3});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/NavBarSectores.js






const NavBarSectores = ()=>{
    const { asPath  } = (0,router_.useRouter)();
    const [estiloNavBar, setEstiloNavBar] = (0,external_react_.useState)(true);
    const [submenu, setSubmenu] = (0,external_react_.useState)(false);
    const submenuProductos = ()=>{
        setSubmenu(!submenu);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "relative z-10",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-row items-center justify-between px-2  bg-slate-100 mb-5 py-2 lg:relative pr-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-row items-center ml-3",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "w-1/3 lg:w-1/2",
                            src: logo_HPampa,
                            alt: "logohpampa",
                            width: 200,
                            height: 30
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    onClick: ()=>setEstiloNavBar(!estiloNavBar),
                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        className: "w-5 h-5 lg:hidden",
                        "aria-hidden": "true",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 17 14",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            stroke: "currentColor",
                            strokeLinecap: "round",
                            strokeLinejoin: "round",
                            strokeWidth: "2",
                            d: "M1 1h15M1 7h15M1 13h15"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: `${estiloNavBar ? "hidden" : "flex flex-col"} justify-center items-center w-full text-2xl left-0 top-14 bg-slate-100 py-3 absolute lg:flex lg:top-auto lg:text-lg lg:flex-row lg:static lg:justify-around  lg:w-1/2`,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            className: asPath === "/consultoria" ? "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg xl:font-bold lg:text-slate-800 lg:border-b-2 lg:border-solid lg:border-x-slate-900" : "text-lg lg:text-sm xl:text-lg  py-4 lg:py-0  lg:text-slate-800",
                            href: "/consultoria",
                            children: "Consultoria"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "hidden lg:block",
                            onClick: submenuProductos,
                            children: "Productos"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: `flex flex-col lg:flex-col justify-center items-center gap-6 lg:items-start ${submenu ? "absolute" : "lg:hidden"} bg-slate-100 p-5 lg:top-20 lg:translate-x-4`,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: asPath === "/bebidas" ? "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg xl:font-bold lg:text-slate-800 lg:border-b-2 lg:border-solid lg:border-x-slate-900" : "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg  lg:text-slate-800",
                                    href: "/bebidas",
                                    children: "Bebidas"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: asPath === "/carnes" ? "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg xl:font-bold lg:text-slate-800 lg:border-b-2 lg:border-solid lg:border-x-slate-900" : "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg  lg:text-slate-800",
                                    href: "/carnes",
                                    children: "Carnes"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: asPath === "/legumbres" ? "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg xl:font-bold lg:text-slate-800 lg:border-b-2 lg:border-solid lg:border-x-slate-900" : "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg  lg:text-slate-800",
                                    href: "/legumbres",
                                    children: "Legumbres"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: asPath === "/frutossecos" ? "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg xl:font-bold lg:text-slate-800 lg:border-b-2 lg:border-solid lg:border-x-slate-900" : "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg  lg:text-slate-800",
                                    href: "/frutossecos",
                                    children: "Frutos secos"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: asPath === "/alimentos" ? "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg xl:font-bold lg:text-slate-800 lg:border-b-2 lg:border-solid lg:border-x-slate-900" : "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg lg:text-slate-800",
                                    href: "/alimentos",
                                    children: "Alimentos Diarios"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "absolute text-ssm translate-x-14 lg:-translate-y-3 text-emerald-600 font-bold cursor-default",
                                    children: "Pr\xf3ximamente"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "py-4 text-lg lg:py-0 lg:text-sm xl:text-lg cursor-default",
                                    children: "Novedades"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_NavBarSectores = (NavBarSectores);


/***/ })

};
;