"use strict";
exports.id = 366;
exports.ids = [366];
exports.modules = {

/***/ 2366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/logo-HPampaBlanco.png
/* harmony default export */ const logo_HPampaBlanco = ({"src":"/_next/static/media/logo-HPampaBlanco.bb2f266f.png","height":1221,"width":632,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAQAAAAICAMAAADp7a43AAAAKlBMVEX////////////////////////////////////////////////////+/v4FJSbNAAAADnRSTlMEKma4Rz+BVKs0mnYXz3YEcHUAAAAJcEhZcwAALiMAAC4jAXilP3YAAAAnSURBVHicBcEHAQAgDMCw7h/Av10SIgCrmxxVZXIFbxteebPiBoh8DS8AnuvL/fIAAAAASUVORK5CYII=","blurWidth":4,"blurHeight":8});
// EXTERNAL MODULE: external "@googlemaps/js-api-loader"
var js_api_loader_ = __webpack_require__(5486);
;// CONCATENATED MODULE: ./components/Maps.js



const Map = ()=>{
    const mapRef = (0,external_react_.useRef)(null);
    (0,external_react_.useEffect)(()=>{
        const initMap = async ()=>{
            const loader = new js_api_loader_.Loader({
                apiKey: "AIzaSyA6CPfTPehi0D2zk0_jjHeISuOFvXeoqmk",
                VERSION: "weekly"
            });
            const { Map  } = await loader.importLibrary("maps");
            const posicion = {
                lat: parseFloat(-31.243888407845628),
                lng: parseFloat(-64.46761913905584)
            };
            const mapOptions = google.maps.MapOptions = {
                center: posicion,
                zoom: 13,
                mapId: "M"
            };
            const map = new Map(mapRef.current, mapOptions);
        };
        initMap();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "w-42 ",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            ref: mapRef,
            style: {
                height: "200px",
                width: "100%"
            }
        })
    });
};
/* harmony default export */ const Maps = (Map);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Footer.js






const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                className: "spikes"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-5 flex flex-col sm:flex-row lg:flex-row justify-center items-center lg:items-start bg-slate-800 sm:px-10 lg:px-20",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-1/3 sm:my-20 lg:my-14 px-7 sm:px-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "m-3",
                            src: logo_HPampaBlanco,
                            alt: "logohpampa",
                            width: 70,
                            height: 40
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-wrap gap-5 flex-row justify-center sm:items-start sm:justify-between sm:w-2/3 lg:w-2/3 py-5",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-hpampa lg:text-2xl mb-5",
                                        children: "Nuestras redes"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "https://www.linkedin.com/company/hpampa/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-blanco sm:text-xs lg:text-lg cursor-pointer mb-1 hover:underline",
                                            children: "Linkedin"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "https://www.instagram.com/hpampacomex/",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-blanco sm:text-xs lg:text-lg cursor-pointer mb-1 hover:underline",
                                            children: "Instagram"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "https://api.whatsapp.com/send/?phone=%2B34606568570&text&type=phone_number&app_absent=0",
                                        target: "_blank",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-blanco sm:text-xs lg:text-lg cursor-pointer mb-1 hover:underline",
                                            children: "Whatsapp"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-hpampa lg:text-2xl mb-5",
                                        children: "Encontranos"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Maps, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-blanco sm:text-xs lg:text-sm mt-2 mb-1",
                                        children: "Espa\xf1a, Espa\xf1a"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-hpampa lg:text-2xl mb-5",
                                        children: "Contacto"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "mailto:consultas@hpampa.com",
                                        className: "text-blanco text-ssm lg:text-lg cursor-pointer sm:text-xs mb-1 hover:underline",
                                        children: "consultas@hpampa.com"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Footer = (Footer);


/***/ })

};
;