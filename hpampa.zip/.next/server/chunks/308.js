"use strict";
exports.id = 308;
exports.ids = [308];
exports.modules = {

/***/ 6308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7163);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_emailjs_browser__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var dotenv_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1081);
/* harmony import */ var dotenv_config__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(dotenv_config__WEBPACK_IMPORTED_MODULE_5__);






const FormControl = ()=>{
    const formRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const formik = (0,formik__WEBPACK_IMPORTED_MODULE_1__.useFormik)({
        initialValues: {
            nombreEmpresa: "",
            nombreContacto: "",
            email: "",
            pais: "",
            telefono: undefined,
            consulta: ""
        },
        validationSchema: yup__WEBPACK_IMPORTED_MODULE_3__.object({
            nombreEmpresa: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("El campo es requerido").max(20, "El campo no puede tener mas de 20 caracteres"),
            nombreContacto: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("El campo es requerido").max(20, "El campo no puede tener mas de 20 caracteres"),
            email: yup__WEBPACK_IMPORTED_MODULE_3__.string().email("El email no es valido").required("El campo es requerido"),
            pais: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("El campo es requerido"),
            telefono: yup__WEBPACK_IMPORTED_MODULE_3__.number(),
            consulta: yup__WEBPACK_IMPORTED_MODULE_3__.string().required("El campo es requerido").max(300, "El campo no puede tener mas de 300 caracteres")
        }),
        onSubmit: (values)=>{
            try {
                _emailjs_browser__WEBPACK_IMPORTED_MODULE_4___default().sendForm("service_n262jdu", "template_dgup889", formRef.current, "Kj0aBGhfa1OrVV5EZ").then((res)=>console.log(res)).catch((err)=>console.log(err));
            } catch (error) {
                console.log(error);
            }
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        ref: formRef,
        className: "w-full",
        onSubmit: formik.handleSubmit,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col items-center justify-center w-full",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    id: "nombreEmpresa",
                    name: "nombreEmpresa",
                    className: "mb-5 bg-transparent border-t-transparent border-l-transparent border-r-transparent placeholder:text-slate-700  border-slate-800 text-gray-900 text-xl border-2 focus:border-b-blue-500 focus:border-t-transparent focus:border-l-transparent focus:border-r-transparent focus:outline-none focus:ring-transparent block w-full p-2.5",
                    placeholder: "Nombre compa\xf1\xeda",
                    value: formik.values.nombreEmpresa,
                    onChange: formik.handleChange,
                    onBlur: formik.handleBlur
                }),
                formik.touched.nombreEmpresa && formik.errors.nombreEmpresa ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-2 w-full bg-red-100 border-l-4 border-red-500 text-red-700 p-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "font-bold",
                            children: "Error"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: formik.errors.nombreEmpresa
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    id: "nombreContacto",
                    name: "nombreContacto",
                    className: "mb-5  bg-transparent border-t-transparent border-l-transparent border-r-transparent placeholder:text-slate-700 border-slate-800 text-gray-900 text-xl border-2 focus:border-b-blue-500 focus:border-t-transparent focus:border-l-transparent focus:border-r-transparent focus:outline-none focus:ring-transparent block w-full p-2.5",
                    placeholder: "Nombre de contacto",
                    value: formik.values.nombreContacto,
                    onChange: formik.handleChange,
                    onBlur: formik.handleBlur
                }),
                formik.touched.nombreContacto && formik.errors.nombreContacto ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-2 w-full bg-red-100 border-l-4 border-red-500 text-red-700 p-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "font-bold",
                            children: "Error"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: formik.errors.nombreContacto
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "email",
                    id: "email",
                    name: "email",
                    className: "mb-5  bg-transparent border-t-transparent border-l-transparent border-r-transparent placeholder:text-slate-700 border-slate-800 text-gray-900 text-xl border-2 focus:border-b-blue-500 focus:border-t-transparent focus:border-l-transparent focus:border-r-transparent focus:outline-none focus:ring-transparent block w-full p-2.5",
                    placeholder: "Email",
                    value: formik.values.email,
                    onChange: formik.handleChange,
                    onBlur: formik.handleBlur
                }),
                formik.touched.email && formik.errors.email ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-2 w-full bg-red-100 border-l-4 border-red-500 text-red-700 p-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "font-bold",
                            children: "Error"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: formik.errors.email
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    id: "pais",
                    name: "pais",
                    className: "mb-5  bg-transparent border-t-transparent border-l-transparent border-r-transparent placeholder:text-slate-700 border-slate-800 text-gray-900 text-xl border-2 focus:border-b-blue-500 focus:border-t-transparent focus:border-l-transparent focus:border-r-transparent focus:outline-none focus:ring-transparent block w-full p-2.5",
                    placeholder: "Pa\xeds",
                    value: formik.values.pais,
                    onChange: formik.handleChange,
                    onBlur: formik.handleBlur
                }),
                formik.touched.pais && formik.errors.pais ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-2 w-full bg-red-100 border-l-4 border-red-500 text-red-700 p-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "font-bold",
                            children: "Error"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: formik.errors.pais
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "tel",
                    id: "telefono",
                    name: "telefono",
                    className: "mb-5  bg-transparent border-t-transparent border-l-transparent border-r-transparent placeholder:text-slate-700 border-slate-800 text-gray-900 text-xl border-2 focus:border-b-blue-500 focus:border-t-transparent focus:border-l-transparent focus:border-r-transparent focus:outline-none focus:ring-transparent block w-full p-2.5",
                    placeholder: "Tel\xe9fono",
                    value: formik.values.telefono,
                    onChange: formik.handleChange,
                    onBlur: formik.handleBlur
                }),
                formik.touched.telefono && formik.errors.telefono ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-2 w-full bg-red-100 border-l-4 border-red-500 text-red-700 p-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "font-bold",
                            children: "Error"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: formik.errors.telefono
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                    type: "text",
                    id: "consulta",
                    name: "consulta",
                    className: "mb-5 bg-transparent border-t-transparent border-l-transparent border-r-transparent placeholder:text-slate-700 border-slate-800 text-gray-900 text-xl border-2 focus:border-b-blue-500 focus:border-t-transparent focus:border-l-transparent focus:border-r-transparent focus:outline-none focus:ring-transparent block w-full p-2.5",
                    placeholder: "Escriba su consulta",
                    value: formik.values.consulta,
                    onChange: formik.handleChange,
                    onBlur: formik.handleBlur
                }),
                formik.touched.consulta && formik.errors.consulta ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-2 w-full bg-red-100 border-l-4 border-red-500 text-red-700 p-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "font-bold",
                            children: "Error"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: formik.errors.consulta
                        })
                    ]
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "submit",
                    className: "text-white bg-gray-dark hover:bg-slate-700 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-xl  px-5 py-2.5 mt-5 mb-10 w-3/4 text-center",
                    children: "Enviar"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormControl);


/***/ })

};
;